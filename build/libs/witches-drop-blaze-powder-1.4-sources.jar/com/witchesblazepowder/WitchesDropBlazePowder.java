package com.witchesblazepowder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_1802;
import net.minecraft.class_221;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class WitchesDropBlazePowder implements ModInitializer {

    @Override
    public void onInitialize() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!key.method_29177().toString().equals("minecraft:entities/witch")) return;

            class_55 blazePool = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(
                        class_77.method_411(class_1802.field_8183)
                            .method_438(class_141.method_621(
                                class_5662.method_32462(1.0f, 2.0f)
                            ))
                    )
                    .method_356(class_221.method_939())
                    .method_355();

            tableBuilder.pool(blazePool);
        });
    }
}
